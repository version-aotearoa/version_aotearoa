# Threlte Model Pipeline Components

This directory holds automatically generated Threlte components from GLTF models.

Place your models in `static/models` and run `npm run model-pipeline:run` to generate the components.
